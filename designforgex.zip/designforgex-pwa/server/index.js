const express = require('express');
const bodyParser = require('body-parser');
const app = express();

app.use(bodyParser.json());
app.use('/api/chat', require('./routes/chat'));
app.use('/api/vault', require('./routes/vault'));
app.use('/api/plugins', require('./routes/plugins'));

app.listen(3000, () => console.log("DesignForgeX backend running on port 3000"));