const express = require('express');
const router = express.Router();
const { executePlugin } = require('../sarthidesigns/pluginManager');

router.post('/run', (req, res) => {
  const { pluginName, params } = req.body;
  const result = executePlugin(pluginName, params);
  res.json({ success: true, output: result });
});

module.exports = router;