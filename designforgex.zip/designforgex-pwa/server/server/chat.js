const express = require('express');
const router = express.Router();
const { interpret } = require('../sarthidesigns/engineCore');

router.post('/interpret', (req, res) => {
  const { message } = req.body;
  const result = interpret(message);
  res.json({ reply: result.reply });
});

module.exports = router;