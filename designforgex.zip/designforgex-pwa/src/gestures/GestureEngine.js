export function detectGesture(data) {
  // Connect with MediaPipe or WebRTC for tracking
  // Placeholder for gesture interpretation
  return "none"; // example return: "zoom", "rotate", "select"
}