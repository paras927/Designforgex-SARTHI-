import React, { useState } from 'react';

export default function ChatPanel() {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');

  function sendMessage() {
    const userMsg = { sender: 'user', text: input };
    setMessages([...messages, userMsg]);

    fetch('/api/chat/interpret', {
      method: 'POST',
      body: JSON.stringify({ message: input }),
      headers: { 'Content-Type': 'application/json' }
    })
      .then(res => res.json())
      .then(data => {
        setMessages(prev => [...prev, { sender: 'sarthi', text: data.reply }]);
        setInput('');
      });
  }

  return (
    <div className="chat-box mb-4">
      <div className="overflow-y-auto h-64">
        {messages.map((m, i) => (
          <div key={i} className={`text-${m.sender === 'user' ? 'right' : 'left'}`}>
            {m.text}
          </div>
        ))}
      </div>
      <input
        value={input}
        onChange={e => setInput(e.target.value)}
        className="w-full mt-2 p-2 rounded bg-gray-100"
        placeholder="Describe your idea..."
      />
      <button onClick={sendMessage} className="mt-2 bg-indigo-600 text-white px-4 py-1 rounded">
        Send
      </button>
    </div>
  );
}