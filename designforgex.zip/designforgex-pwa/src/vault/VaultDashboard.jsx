import React, { useEffect, useState } from 'react';

export default function VaultDashboard() {
  const [entries, setEntries] = useState([]);

  useEffect(() => {
    fetch('/api/vault/list')
      .then(res => res.json())
      .then(data => setEntries(data.entries));
  }, []);

  return (
    <div className="vault-panel mt-4">
      <h2 className="text-lg font-bold">Vault Entries</h2>
      <ul>
        {entries.map((entry, i) => (
          <li key={i} className="bg-gray-100 p-2 my-2 rounded">
            <strong>{entry.name}</strong> — {new Date(entry.timestamp).toLocaleString()}
            <br />
            Tags: {entry.tags.join(', ')}
          </li>
        ))}
      </ul>
    </div>
  );
}